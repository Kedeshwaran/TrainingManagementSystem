package com.cognizant.tms.dao;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.tms.entity.CourseEntity;


public interface CoursesRepository extends JpaRepository<CourseEntity,Integer>{
	
	@Query("SELECT c FROm CourseEntity c WHERE c.skills=?1")
	List<CourseEntity> mapCourse(String skills);

	@Query("SELECT DISTINCT c.skills FROm CourseEntity c")
	List<String> fetchDistinctCourses();

	@Query("SELECT c.coursecode FROM CourseEntity c WHERE c.coursedescription=?1")
	int fetchCoursecode(String coursedesc);
	
	

}
