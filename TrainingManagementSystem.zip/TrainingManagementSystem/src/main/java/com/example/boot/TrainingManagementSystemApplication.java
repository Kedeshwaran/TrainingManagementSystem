package com.example.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan({"com.cognizant.tms.controller"})
@ComponentScan({"com.cognizant.tms.service"})
@EntityScan("com.cognizant.tms.entity")
@EnableJpaRepositories(basePackages="com.cognizant.tms.dao")
public class TrainingManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingManagementSystemApplication.class, args);
	}

}
