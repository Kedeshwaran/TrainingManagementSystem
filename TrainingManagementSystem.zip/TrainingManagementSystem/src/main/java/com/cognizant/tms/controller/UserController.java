package com.cognizant.tms.controller;



import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cognizant.tms.model.Assessment;
import com.cognizant.tms.model.Course;
import com.cognizant.tms.model.Test;
import com.cognizant.tms.model.User;
import com.cognizant.tms.model.UserLogin;
import com.cognizant.tms.service.UserService;
import com.example.boot.RecordNotFoundException;




@Controller
public class UserController {
@Autowired
UserService userService;

public void setAdminService(UserService userService) {
	this.userService = userService;
}
@RequestMapping("/Register")
public String createreg(Model model) {
	model.addAttribute("user", new User());
    return "userregistration";
}
@RequestMapping(value ="/userRegister",method=RequestMethod.POST)
public String adminRegister(@Valid @ModelAttribute("user")User user,BindingResult bresult,
		ModelMap model,RedirectAttributes redirectAttribute)
{
 	
	if (bresult.hasErrors()) {
		return "userregistration";
	}
	else {
	String result=userService.addUser(user);
	 if(result.equals("exists"))
	     
	       model.addAttribute("msg","User Id already exists");
	 	
	       else if(result.equals("success"))
	  
	          model.addAttribute("msg","Details saved successfully");
	return "userlogin";
	}	
}
@RequestMapping(value ="/userValidate",method=RequestMethod.POST)
public String validateLogin(@Valid @ModelAttribute("user") UserLogin user,BindingResult bresult,
		ModelMap model,RedirectAttributes redirectAttribute) {
	System.out.println("controller is called");
	 String result = "";
	if (bresult.hasErrors()) {
			return "userlogin";
		}
		else {
		
UserLogin a = userService.validateUser(user);
System.out.println(a);
if (a != null) {
if (a.getRole().equalsIgnoreCase("admin")) {
    result ="adminhomepage";
}
else if (a.getRole().equalsIgnoreCase("employee")) 
	 result ="employeehomepage";
}
	else {
    model.addAttribute("invalid", "Invalid username/password");
    result = "userlogin";
}

}

return result;
		}	

@RequestMapping("/Login")
public String adminLogin(Model model) {
	 model.addAttribute("user",new UserLogin());
	 return "userlogin";
}
@RequestMapping("/adminLogout")
public String adminLogout(Model model) {
	 model.addAttribute("user",new UserLogin());
	 return "userlogin";
}
@RequestMapping("/employeeLogout")
public String employeeLogout(Model model) {
	 model.addAttribute("user",new UserLogin());
	 return "userlogin";
}
@RequestMapping("/createCourse")
public String createcourse(Model model) {
	model.addAttribute("course", new Course ());
    return "coursecontent";
	
}

@RequestMapping(value="/addCourse" ,method=RequestMethod.POST)
public String addcourse(@Valid @ModelAttribute("course")Course course,BindingResult bresult,ModelMap model) {
	if(bresult.hasErrors()) {
		return "coursecontent";
	}
	else {
		
		boolean result=userService.addCourse(course);
		System.out.println("result="+result);
		 model.addAttribute("msg1","Details saved successfully");
	}
		return "success";


}



@RequestMapping("/showCourseList")
public  String getcourses(ModelMap model)
{
	List<Course> courseList=userService.fetchCourses();
	model.addAttribute("courselist",courseList);
	return "courseupdatelist";
	
}

@RequestMapping("/showCourse/{coursecode}")
public String showupdatecourse(Model model,@PathVariable("coursecode")int code) {
	System.out.println(code);
    Course course=userService.getCourses(code);
   
  model.addAttribute("command", course);
    return "editcourse";
}

@PostMapping(value = "/updateCourse")
public String updateEmployee(@ModelAttribute("course")Course course)
{
	
boolean result=userService.updateCourses(course);
System.out.println(result);
    return "redirect:/showCourseList";
}
@RequestMapping("/adminHomePage")
public String adminHomePage() {
	return "adminhomepage";
	
}
@RequestMapping("/employeeHomePage")
public String employeeHomePage() {
	return "employeehomepage";
	
}
@RequestMapping("/addAssessment")
public String  addassessment(Model model)
{
	model.addAttribute("assessment", new Assessment());
	return "assessmentform";
	
}

@RequestMapping(value="/addQuestions" ,method=RequestMethod.POST)
public String addquestions(@Valid @ModelAttribute("assessment")Assessment assess,BindingResult bresult,ModelMap model) {
	if(bresult.hasErrors()) {
		return "assessmentform";
	}
	else {
		System.out.println("code="+assess.getCoursecode());
		boolean result=userService.addAssessment(assess);
		model.addAttribute("msg1","Your Details Added Successfully");
		System.out.println("result="+result);
	}
		return "success";
	}
@RequestMapping("/showQuestionList/{coursecode}")
public  String getQuestion(ModelMap model,@PathVariable("coursecode") int code)
{
	List<Assessment> quesList=userService.fetchQuestion(code);
	System.out.println(quesList.size());
	model.addAttribute("queslist",quesList);
	return "assessmentlist";
	
}
//UPDATE QUESTIONS/ANSWERS
@RequestMapping("/showQuestion/{questionId}")
public String  getAssessment(ModelMap model,@PathVariable("questionId")int questionId) {
	System.out.println( "quesId" +questionId);
   Assessment assessment=userService.getQuestion(questionId);
   
  model.addAttribute("command",assessment );
    return "editassessment";
	
}

@RequestMapping("/updateAssessment")
public String showCourseList(Model model) {
	return "redirect:/showCourseList";
}
@PostMapping(value = "/updateQuestions")
public String updatequestions(@ModelAttribute("assessment")Assessment assess)
{
	
boolean result=userService.updateAssessment(assess);
System.out.println(result);
    return "redirect:/showCourseList";
}
//COURSE MAPPING WITH SKILL

	@RequestMapping("/selectskill")
	public String selectskill(Model model,@ModelAttribute("course")Course course) {
		List<String> courseList=userService.fetchDistinctCourses();
		System.out.println(courseList);
		model.addAttribute("courselist",courseList);
		return "selectskill";
	}
	//Employee based actions
	@RequestMapping(value="/courseMapping" ,method=RequestMethod.POST)
	public String coursemapping(@ModelAttribute("course")Course course, Model model) {
		List<Course> c=userService.mapCourse(course.getSkills());
		System.out.println(c);
	    if(c==null)
	    	throw new RecordNotFoundException();
	    model.addAttribute("clist", c);
	    return "mappedcoursesdisplay";
	}
	@RequestMapping("/startLearningJava")
	public String startLearning(Model model) {
		return "javapage1";
		
	}
	
	@RequestMapping("/nexttopage2")
	public String nextToPage2(Model model) {
		return "javapage2";
		
	}
	@RequestMapping("/nexttopage3")
	public String nextToPage3(Model model) {
		return "javapage3";
	}
	@RequestMapping("/previoustopage1")
	public String previousToPage1(Model model) {
		return "javapage1";
	}
	@RequestMapping("/previoustopage2")
	public String previousToPage2(Model model) {
		return "javapage2";
	}
	@RequestMapping(value="/gotocoursepage" ,method=RequestMethod.POST)
	public String gotoCoursePage(@ModelAttribute("course")Course course,Model model) {
		return "success1";
		
	}
	//SHOW ASSESSMENTS TO EMPLOYEE
	
		@RequestMapping("/Assessments")
		public String assessments(Model model,@ModelAttribute("course")Course course) {
			List<Course> coursedescList=userService.fetchCourses();
			System.out.println("course list="+coursedescList);
			
			model.addAttribute("coursedesclist",coursedescList );
			return "selectcoursemapassess";
		}
		
//		@RequestMapping(value="/assessMapping")
//		public String assessmapping(@ModelAttribute("course")Course course,@ModelAttribute("assessment")Assessment assessment,Model model) {
//			int c=adminservice.fetchCoursecode(course.getCoursedescription());
//			System.out.println("code="+c);
//	       List<Assessment> aList=adminservice.fetchAssessment(c);
//	       System.out.println("list :"+aList.size());
//			model.addAttribute("alist", aList);
//			return "Test";
//			
//		}
		private static List<Assessment> aList = new ArrayList<Assessment>();
		
		@RequestMapping(value="/assessMapping")
		public String assessmapping(@ModelAttribute("course")Course course,@ModelAttribute("test")Test test,Model model) {
			int c=userService.fetchCoursecode(course.getCoursedescription());
			System.out.println("code="+c);
			
			aList=userService.fetchAssessment(c);
			
			//Test testList=new Test();
			test.setaList(aList);
			 System.out.println("list :"+aList);
			// System.out.println("list :"+testList);
	       System.out.println("list :"+aList.size());
			model.addAttribute("questionList", test);
			return "test";
			
		}
		
		
		
		@RequestMapping(value = "/save", method = RequestMethod.POST)
	    public String save(@ModelAttribute("test") Test test,Model model) {
			int count=0;
	        System.out.println(test);
	        System.out.println("question list"+test.getaList());
	        List<Assessment> assessmentList = test.getaList();
	        for(Assessment a:assessmentList) {
	        	userService.save(a);
	        	String correctAns=userService.getCorrectAns(a.getQuestionId());
	        	System.out.println(correctAns);
	        	String Options=userService.getOptions(a.getQuestionId());
	        	System.out.println(Options);
	        	
	        	if(correctAns.equals(Options)) {
	        		count++;
	        	}	
	        	
	        }
	        
	        if(count==assessmentList.size())
	        	System.out.println("count is "+assessmentList.size());
	       model.addAttribute("c", count);
	       model.addAttribute("size", assessmentList.size());
			return "testresult";
	
			
			
		}
		@RequestMapping("/forgetPassword/{userId}")
		public String forgetPass(Model model,@PathVariable("userId")String userId ) {
			User user=userService.getuser(userId);
			model.addAttribute("user",user);
			return "forgetpassword";
		}
				}