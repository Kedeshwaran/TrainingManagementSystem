package com.cognizant.tms.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="course")
public class CourseEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="coursecode")
	private int coursecode;
	private String coursedescription;
	private String skills;
	private String competencylevel;
	private String intendedaudience;
	
	@OneToMany(mappedBy="coursecode", fetch=FetchType.LAZY, cascade= {CascadeType.ALL})
	private Set<AssessmentEntity> assessment;
	
	
	
	
	public Set<AssessmentEntity> getAssessment() {
		return assessment;
	}
	public void setAssessment(Set<AssessmentEntity> assessment) {
		this.assessment = assessment;
	}
	public int getCoursecode() {
		return coursecode;
	}
	public void setCoursecode(int coursecode) {
		this.coursecode = coursecode;
	}
	public String getCoursedescription() {
		return coursedescription;
	}
	public void setCoursedescription(String coursedescription) {
		this.coursedescription = coursedescription;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getCompetencylevel() {
		return competencylevel;
	}
	public void setCompetencylevel(String competencylevel) {
		this.competencylevel = competencylevel;
	}
	public String getIntendedaudience() {
		return intendedaudience;
	}
	public void setIntendedaudience(String intendedaudience) {
		this.intendedaudience = intendedaudience;
	}
	
	
}


