package com.cognizant.tms.model;

import java.util.List;


import com.cognizant.tms.model.Assessment;
//import com.cognizant.tms.entity.TestEntity;

public class Test {
	
	private List<Assessment> aList;

	public List<Assessment> getaList() {
		return aList;
	}

	public void setaList(List<Assessment> aList) {
		this.aList = aList;
	}

	

	
}
