package com.cognizant.tms.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.tms.entity.TestEntity;

public interface TestRepository extends JpaRepository<TestEntity,int[]> {

	@Query("SELECT t.optionA,t.optionB,t.optionC,t.optionD from TestEntity t WHERE t.questionId=?1")
	String getOptions(int questionId);
	
	

}
