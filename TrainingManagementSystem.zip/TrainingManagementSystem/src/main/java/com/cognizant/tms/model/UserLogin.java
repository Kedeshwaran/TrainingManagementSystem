package com.cognizant.tms.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class UserLogin {
	@NotEmpty(message="NotEmpty.user.userid")
	private String userId;
	@NotEmpty(message="Password is required")
	@Size(min=6,max=15,message="Size.user.password")
	private String password;
	 private String role;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
		
	

}
