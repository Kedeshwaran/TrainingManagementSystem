package com.cognizant.tms.model;


import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Course {
	
	@NotNull(message="coursecode shouldn't be left empty")
	private int coursecode;
	
	@NotEmpty(message="NotEmpty.course.coursedescription")
	private String coursedescription;
	
	@NotEmpty(message="NotEmpty.course.skills")
	private String skills;
	
	@NotEmpty(message="NotEmpty.course.competencylevel")
	private String competencylevel;
	
	@NotEmpty(message="NotEmpty.course.intendedaudience")
	private String intendedaudience;

	public int getCoursecode() {
		return coursecode;
	}

	public void setCoursecode(int coursecode) {
		this.coursecode = coursecode;
	}

	public String getCoursedescription() {
		return coursedescription;
	}

	public void setCoursedescription(String coursedescription) {
		this.coursedescription = coursedescription;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getCompetencylevel() {
		return competencylevel;
	}

	public void setCompetencylevel(String competencylevel) {
		this.competencylevel = competencylevel;
	}

	public String getIntendedaudience() {
		return intendedaudience;
	}

	public void setIntendedaudience(String intendedaudience) {
		this.intendedaudience = intendedaudience;
	}
	
	
	

}
