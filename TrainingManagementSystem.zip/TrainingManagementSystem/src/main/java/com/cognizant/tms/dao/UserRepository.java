package com.cognizant.tms.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.tms.entity.UserEntity;
import com.cognizant.tms.model.User;




@Repository
public interface UserRepository  extends JpaRepository<UserEntity, String >{

	@Query("SELECT u FROm UserEntity u WHERE u.userId=?1  and u.password=?2")
	

	UserEntity validateUser(String userId, String password);
@Query("select e from UserEntity e where e.userId=?1")
	UserEntity findByuserId(User userId);

	
//	@Query("SELECT e FROm User e WHERE e.UserId = ?1")
//	
//
//	List<User> gettingId();

}
