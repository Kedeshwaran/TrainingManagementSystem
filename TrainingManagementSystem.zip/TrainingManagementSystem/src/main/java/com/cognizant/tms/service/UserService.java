package com.cognizant.tms.service;

import java.util.List;
import javax.validation.Valid;

import com.cognizant.tms.model.Assessment;
import com.cognizant.tms.model.Course;
import com.cognizant.tms.model.User;
import com.cognizant.tms.model.UserLogin;


public interface UserService {


	String addUser(@Valid User user);


	UserLogin validateUser(@Valid UserLogin user);




	List<Course> fetchCourses();


	Course getCourses(int courseCode);


	boolean updateCourses(Course courses);


	boolean addCourse(Course course);


	boolean addAssessment(Assessment assess);


	boolean updateAssessment(Assessment assess);


	List<Assessment> fetchQuestion(int code);


	Assessment getQuestion(int quesId);


	List<Course> mapCourse(String skills);


	List<String> fetchDistinctCourses();


	void save(Assessment a);


	String getCorrectAns(int questionId);


	String getOptions(int questionId);


	int fetchCoursecode(String coursedescription);


	List<Assessment> fetchAssessment(int c);


	User getuser(String userId);


	



	//boolean save(User user);

	//List<User> gettingId(@Valid User user.get);

	//List<User> gettingId();

	//List<User> Adminid();

	//List<User> Admindetails(@Valid String userId);

	//String saveUser(@Valid User user);

	
}
