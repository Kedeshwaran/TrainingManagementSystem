package com.cognizant.tms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.tms.entity.AssessmentEntity;
@Repository
public interface AssessmentRepository extends JpaRepository<AssessmentEntity,Integer>{
@Query("SELECT a FROM AssessmentEntity a where a.coursecode.coursecode=?1")
List<AssessmentEntity> findByCourseCode(int coursecode);

@Query("SELECT a.correctans FROM AssessmentEntity a WHERE a.questionId=?1")
String getCorrectAns(int questionId);
@Query("SELECT a FROM AssessmentEntity a where a.coursecode.coursecode=?1")
List<AssessmentEntity> fetchAssessment(int c);


}
