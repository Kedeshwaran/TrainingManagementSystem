package com.cognizant.tms.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.tms.dao.AssessmentRepository;
import com.cognizant.tms.dao.CoursesRepository;
//import com.cognizant.tms.dao.ForgetPasswordRepository;
import com.cognizant.tms.dao.TestRepository;
import com.cognizant.tms.dao.UserRepository;
import com.cognizant.tms.entity.AssessmentEntity;
import com.cognizant.tms.entity.CourseEntity;
import com.cognizant.tms.entity.TestEntity;
import com.cognizant.tms.entity.UserEntity;
import com.cognizant.tms.model.Assessment;
import com.cognizant.tms.model.Course;
import com.cognizant.tms.model.User;
import com.cognizant.tms.model.UserLogin;




@Service
public class UserServiceImpl implements UserService {
@Autowired
UserRepository userDao;
@Autowired
CoursesRepository courseDao;
@Autowired
AssessmentRepository assessRepo;
@Autowired
TestRepository testRepo;
//@Autowired
//ForgetPasswordRepository frpassRepo;
@Autowired
private ModelMapper  modelMapper;
@Override
@Transactional
public String addUser(@Valid User user) {
	  
    // TODO Auto-generated method stub

    String result="success";
     
UserEntity u = modelMapper.map(user, UserEntity.class);

      boolean found=userDao.existsById(user.getUserId());

    System.out.println("found="+found);
   
 if(found)
   
 {
          result="exists";
 
  
}
    
else
      {
 
   UserEntity res=userDao.save(u);
  
  if(res==null)

    result="failure";
      }
return result;
}
@Override
@Transactional
public UserLogin validateUser(@Valid UserLogin user) {
	// TODO Auto-generated method stub
	UserLogin userDto=null;
	UserEntity u=userDao.validateUser(user.getUserId(),user.getPassword());
	if(u!=null)
	{
	userDto = modelMapper.map(u, UserLogin.class);
	}
	return userDto;
	
}
@Override
@Transactional
public boolean addCourse(Course course) {
	boolean result=false;
	CourseEntity c=modelMapper.map(course, CourseEntity.class);
	CourseEntity res=courseDao.save(c);
	if(res!=null)
		result=true;
	return result;
	
	
}


@Override
@Transactional
public List<Course> fetchCourses() {
    List<CourseEntity> entityList=courseDao.findAll();
     List<Course> modellist = new ArrayList<>();
     for(CourseEntity u:entityList)
     {
    	 
     Course c=modelMapper.map(u, Course.class);
     modellist.add(c);
    
     System.out.println(modellist);
     }
     
    return modellist;
}

@Override
@Transactional
public Course getCourses(int code) {
	CourseEntity c=courseDao.findById(code).get();
	Course res=modelMapper.map(c, Course.class);
	return res;
}

@Override
@Transactional
public boolean updateCourses(Course course) {
	boolean result=false;
	CourseEntity c=modelMapper.map(course, CourseEntity.class);
	CourseEntity res=courseDao.save(c);
	if(res!=null)
		result=true;
	return result;
		
	
}
@Override
@Transactional
public boolean addAssessment(Assessment assess) {
	boolean result=false;
	System.out.println(assess.getCoursecode());
	CourseEntity entity=courseDao.getOne(assess.getCoursecode());
	AssessmentEntity c=modelMapper.map(assess, AssessmentEntity.class);
	c.setCoursecode(entity);
	AssessmentEntity res=assessRepo.save(c);
	if(res!=null)
		result=true;
	return result;
}



@Override
public boolean updateAssessment(Assessment assess) {
	boolean result=false;
	AssessmentEntity c=modelMapper.map(assess, AssessmentEntity.class);
	AssessmentEntity res=assessRepo.save(c);
	if(res!=null)
		result=true;
	return result;
}
@Override
public List<Assessment> fetchQuestion(int code){
	// TODO Auto-generated method stub
	System.out.println("code "+code);
	List<AssessmentEntity> assesslist=assessRepo.findByCourseCode(code);
    List<Assessment> queslist = new ArrayList<>();
    for(AssessmentEntity u:assesslist)
    {
   	 
    	Assessment c=modelMapper.map(u, Assessment.class);
    queslist.add(c);
   
    System.out.println(queslist);
    }
    
   return queslist;
}
@Override
public Assessment getQuestion(int quesId) {
	// TODO Auto-generated method stub
	AssessmentEntity c=assessRepo.findById(quesId).get();
	Assessment res=modelMapper.map(c, Assessment.class);
	return res;
}

@Override
@Transactional
public List<Course> mapCourse(String skills) {
//	CourseEntity courseEntity=courserepo.mapCourse(skills);
//	Course c=modelMapper.map(courseEntity, Course.class);
	List<CourseEntity> courseEntity=courseDao.mapCourse(skills);
	List<Course> course=new ArrayList<>();
	for(CourseEntity c:courseEntity)
	{
		Course res=modelMapper.map(c, Course.class);
		course.add(res);
	}
	
	
	return course;
}

@Override
public List<String> fetchDistinctCourses() {
//	List<String> courseEntity=courserepo.fetchDistinctCourses();
//	System.out.println(courseEntity);
//	List<Course> modelList=new ArrayList<>();
//	for(String c:courseEntity)
//	{
//		Course res=modelMapper.map(c, Course.class);
//        System.out.println(res);
//		modelList.add(res);
//	}
//	return modelList;
	List<String> course=courseDao.fetchDistinctCourses();
	return course;
	
}


@Override
@Transactional
public int fetchCoursecode(String coursedesc) {
	int c=courseDao.fetchCoursecode(coursedesc);
	//Course code=modelMapper.map(c,Course.class);
	return c;
}

@Override
@Transactional
public List<Assessment> fetchAssessment(int c) {
	List<AssessmentEntity> list=assessRepo.fetchAssessment(c);
	List<Assessment> modellist=new ArrayList<>();
	
	for(AssessmentEntity a:list)
	{
		Assessment res=modelMapper.map(a, Assessment.class);
		modellist.add(res);
		System.out.println("service list :"+modellist.size());
	}
	return modellist;
}





@Override
@Transactional
public void save(Assessment a) {
	TestEntity t=modelMapper.map(a, TestEntity.class);
	testRepo.save(t);
	
}

@Override
public String getCorrectAns(int questionId) {
	String correctAns=assessRepo.getCorrectAns(questionId);
	return correctAns;
}

@Override
public String getOptions(int questionId) {
	String options=testRepo.getOptions(questionId);
	return options;
}
@Override
public User getuser(String userId) {
	// TODO Auto-generated method stub
	UserEntity u=userDao.findById(userId).get();
	User user=modelMapper.map(u, User.class);
	return user;
}


}



