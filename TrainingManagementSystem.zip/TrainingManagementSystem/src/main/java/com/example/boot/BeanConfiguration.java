package com.example.boot;



import org.modelmapper.ModelMapper;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class BeanConfiguration implements WebMvcConfigurer{
	 @Bean
	    public ModelMapper modelMapper() {
	        return new ModelMapper();
	    }
	@Bean(name="messageSource")
	public MessageSource messageSource() {
	    ReloadableResourceBundleMessageSource messageSource
	      = new ReloadableResourceBundleMessageSource();
	     
	    messageSource.setBasename("classpath:message");
	   // messageSource.setDefaultLocale(Locale.ENGLISH);
	    messageSource.setDefaultEncoding("UTF-8");
	    return messageSource;
	}
	
}
